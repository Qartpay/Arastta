Arastta

This plugin belongs to Qartpay payment gateway.
For Installation and Configuration :

Follow these steps :

1 > Login in to admin Section

2 > Go to extension > payment

3 > Upload the zip file

4 > Now click on edit button on extension > payment > Qartpay

5 > Fill these details,

    * MID : (Pay Id),
    * Security Code : (Salt),
    * Order Status : Complete
    * Status : enable

 Click on save and now you can accept payment via Qartpay payment gateway.
